//
//  ViewController.swift
//  Exemplo TableView
//
//  Created by Usuário Convidado on 08/08/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var animal = ["Elefante", "Girafa", "Rinoceronte", "Leão", "Urso"]
    var foto = ["ele", "girafa", "rino", "leao", "urso"]
    var local = ["África/Asia", "África", "África", "África", "Europa/América do Norte"]
    
    @IBOutlet weak var minhaTable: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        minhaTable.dataSource = self
        minhaTable.delegate = self
        // Do any additional setup after loading the view.
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Você selecionou o animal \(indexPath.row)")
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let fundo = UIImageView(image: UIImage(named: "cabecalho"))
        return fundo
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let fundo = UIImageView(image: UIImage(named: "rodape"))
        return fundo
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForFooterInSection section: Int) -> CGFloat {
        return 5
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return animal.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celula = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
       // celula.textLabel?.text = "Item número \(indexPath.row)"
        celula.textLabel?.text = animal[indexPath.row]
       //celula.imageView?.image = UIImage(named: "corinthians.png")
        celula.imageView?.image = UIImage(named:  foto[indexPath.row])
        //a extensão da imagem nao é mais obrigatória
        celula.accessoryType = .detailButton
        celula.detailTextLabel?.text = local[indexPath.row]
        //para aparecer o detalhe precisa ajustar o Style da célula para Subtitle
        return celula
    }
    
    
}

